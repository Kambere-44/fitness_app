package com.codeforany.fitness

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
